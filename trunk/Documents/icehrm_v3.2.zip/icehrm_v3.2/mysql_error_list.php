<?php
$mysqlErrors = array();
$mysqlErrors['CONSTRAINT `Fk_User_Employee` FOREIGN KEY'] = "Can not delete Employee, please delete the User for this employee first.";
